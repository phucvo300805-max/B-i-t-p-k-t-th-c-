WEBSITE BAI THI - Vo Thanh Phuc - 231A010809
Lop: 261INT440701-ct3

CAU TRUC
index.html            Trang chu (menu + the lien ket cac trang)
baitap01/02/03.html   Bai tap 01, 02, 03 (kem code mau)
3baitap_code.html     Gop 3 bai tap code chay truc tiep
baitap22.html         Ket qua Wayground (85/100 dung) + anh images/baitap22.png
baitap23.html         Bai Den keo quan -> den-keo-quan/index.html
lythuyet.html         Tra loi ly thuyet
diemdanh.html         Thong tin diem danh + anh images/diemdanh.jpg
about.html, contact.html   Gioi thieu, Lien he
css/style.css, js/script.js   Giao dien va menu dung chung
images/               avatar.jpg (anh mac dinh, co the thay bang anh that), baitap22.png, baitap23.png, diemdanh.jpg

DEPLOY
1. Dua thu muc len GitHub Pages (hoac hosting bat ky).
2. Lay URL sau khi deploy, dien vao dong "URL Deploy website bai thi" trong diemdanh.html.
